# helper for strings

class Helper(object):
    HELP_M = '''ᴄʜᴏᴏsᴇ ᴛʜᴇ ᴄᴀᴛᴇɢᴏʀʏ ғᴏʀ ᴡʜɪᴄʜ ʏᴏᴜ ᴡᴀɴɴᴀ ɢᴇᴛ ʜᴇʟᴩ.
ᴀsᴋ ʏᴏᴜʀ ᴅᴏᴜʙᴛs ᴀᴛ sᴜᴘᴘᴏʀᴛ ᴄʜᴀᴛ

ᴀʟʟ ᴄᴏᴍᴍᴀɴᴅs ᴄᴀɴ ʙᴇ ᴜsᴇᴅ ᴡɪᴛʜ : /'''
    HELP_ChatGPT = '''CʜᴀᴛGPT

CʜᴀᴛGPT ᴄᴏᴍᴍᴀɴᴅꜱ:

/ask ➠ ǫᴜᴇʀɪᴇs ᴛʜᴇ ᴀɪ ᴍᴏᴅᴇʟ ᴛᴏ ɢᴇᴛ ᴀ ʀᴇsᴘᴏɴsᴇ ᴛᴏ ʏᴏᴜʀ ǫᴜᴇsᴛɪᴏɴ.
'''
    
    HELP_Q = '''ǫᴜᴏᴛʟʏ

ʜᴇʀᴇ ɪs ᴛʜᴇ ʜᴇʟᴘ ғᴏʀ ᴛʜᴇ ǫᴜᴏᴛʟʏ ᴍᴏᴅᴜʟᴇ:

◌ /q : ᴄʀᴇᴀᴛᴇ ᴀ ǫᴜᴏᴛᴇ ғʀᴏᴍ ᴛʜᴇ ᴍᴇssᴀɢᴇ
◌ /q r : ᴄʀᴇᴀᴛᴇ ᴀ ǫᴜᴏᴛᴇ ғʀᴏᴍ ᴛʜᴇ ᴍᴇssᴀɢᴇ ᴡɪᴛʜ ʀᴇᴘʟʏ
'''
    
    HELP_Sticker = '''sᴛɪᴄᴋᴇʀs

sᴛɪᴄᴋᴇʀs ᴄᴏᴍᴍᴀɴᴅꜱ:

/packkang ➠ ᴄʀᴇᴀᴛᴇs ᴀ ᴘᴀᴄᴋ ᴏғ sᴛɪᴄᴋᴇʀs ғʀᴏᴍ ᴀ ᴏᴛʜᴇʀ ᴘᴀᴄᴋ
.
/stickerid ➠ ɢᴇᴛs ᴛʜᴇ sᴛɪᴄᴋᴇʀ ɪᴅ ᴏғ ᴀ sᴛɪᴄᴋᴇʀ.

/kang ➠ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ ᴀɴʏ sᴛɪᴄᴋᴇʀ ʀᴇᴘʟʏ ᴀɴᴅ ᴄʀᴇᴀᴛᴇ ʏᴏᴜʀ ᴏᴡɴ ᴘᴀᴄᴋ.

/mmf ➠ ʀᴇʟᴘʏ ᴀɴʏ sᴛɪᴄᴋᴇʀ ɢᴇᴛ ᴀ ɴᴇᴡ ɴᴀᴍᴇ ʟɪᴋᴇ /mmf RAJABABU 
'''

    HELP_TagAll = '''Tᴀɢ

  Tᴀɢ ᴄᴏᴍᴍᴀɴᴅꜱ:

✿ ᴄʜᴏᴏsᴇ ᴛᴀɢ ɪɴ ʏᴏᴜʀ ᴄʜᴀᴛ ✿

๏ /gmtag ➛ ɢᴏᴏᴅ ᴍᴏʀɴɪɴɢ 
ᴛᴀɢ sᴛᴏᴘ ⇴ /gmstop

๏ /gntag ➛ ɢᴏᴏᴅ ɴɪɢʜᴛ ᴛᴀɢ sᴛᴏᴘ ⇴ /gnstop

๏ /tagall ➛ ʀᴀɴᴅᴏᴍ ᴍᴇssᴀɢᴇ ᴛᴀɢ sᴛᴏᴘ ⇴ /tagoff /tagstop

๏ /hitag ➛ ʀᴀɴᴅᴏᴍ ʜɪɴᴅɪ ᴍᴇssᴀɢᴇ ᴛᴀɢ sᴛᴏᴘ ⇴/histop

๏ /shayari ➛ ʀᴀɴᴅᴏᴍ sʜᴀʏᴀʀɪ ᴛᴀɢ sᴛᴏᴘ ⇴ /shstop

๏ /utag ➛ ᴀɴʏ ᴡʀɪᴛᴛᴇɴ ᴛᴇxᴛ ᴛᴀɢ sᴛᴏᴘ ⇴ /cancel 

๏ /vctag ➛ ᴠᴏɪᴄᴇ ᴄʜᴀᴛ ɪɴᴠɪᴛᴇ ᴛᴀɢ sᴛᴏᴘ ⇴ /vcstop
'''

    HELP_Github = '''𝖦ɪᴛʜᴜʙ

𝖦ɪᴛʜᴜʙ ᴄᴏᴍᴍᴀɴᴅꜱ:

/allrepo : sᴇᴇ ᴀʟʟ ʀᴇᴘᴏ ᴀɴʏ ɢɪᴛʜᴜʙ ᴀᴄᴄᴏᴜɴᴛ ᴇx - /allrepo TEAMPURVI.

/github <ᴜsᴇʀɴᴀᴍᴇ> : ɢᴇᴛ ɪɴғᴏʀᴍᴀᴛɪᴏɴ ᴀʙᴏᴜᴛ ᴀ ɢɪᴛʜᴜʙ ᴜsᴇʀ.
'''
    HELP_Group = '''Gʀᴏᴜᴘ

Gʀᴏᴜᴘ ᴄᴏᴍᴍᴀɴᴅꜱ:

ᴛʜᴇsᴇ ᴀʀᴇ ᴛʜᴇ ᴀᴠᴀɪʟᴀʙʟᴇ ɢʀᴏᴜᴘ ᴍᴀɴᴀɢᴇᴍᴇɴᴛ ᴄᴏᴍᴍᴀɴᴅs:

⦿ /pin ➠ ᴘɪɴs ᴀ ᴍᴇssᴀɢᴇ ɪɴ ᴛʜᴇ ɢʀᴏᴜᴘ.
⦿ /pinned ➠ ᴅɪsᴘʟᴀʏs ᴛʜᴇ ᴘɪɴɴᴇᴅ ᴍᴇssᴀɢᴇ ɪɴ ᴛʜᴇ ɢʀᴏᴜᴘ.
⦿ /unpin ➠ ᴜɴᴘɪɴs ᴛʜᴇ ᴄᴜʀʀᴇɴᴛʟʏ ᴘɪɴɴᴇᴅ ᴍᴇssᴀɢᴇ.
⦿ /staff ➠ ᴅɪsᴘʟᴀʏs ᴛʜᴇ ʟɪsᴛ ᴏғ sᴛᴀғғ ᴍᴇᴍʙᴇʀs.
⦿ /bots ➠ ᴅɪsᴘʟᴀʏs ᴛʜᴇ ʟɪsᴛ ᴏғ ʙᴏᴛs ɪɴ ᴛʜᴇ ɢʀᴏᴜᴘ.
⦿ /settitle ➠ sᴇᴛs ᴛʜᴇ ᴛɪᴛʟᴇ ᴏғ ᴛʜᴇ ɢʀᴏᴜᴘ.
⦿ /setdiscription ➠ sᴇᴛs ᴛʜᴇ ᴅᴇsᴄʀɪᴘᴛɪᴏɴ ᴏғ ᴛʜᴇ ɢʀᴏᴜᴘ.
⦿ /setphoto ➠ sᴇᴛs ᴛʜᴇ ɢʀᴏᴜᴘ ᴘʜᴏᴛᴏ.
⦿ /removephoto ➠ ʀᴇᴍᴏᴠᴇs ᴛʜᴇ ɢʀᴏᴜᴘ ᴘʜᴏᴛᴏ.
'''

    HELP_Extra = '''Exᴛʀᴀ

Exᴛʀᴀ ᴄᴏᴍᴍᴀɴᴅꜱ:

⦿ /math ➠ sᴏʟᴠᴇs ᴍᴀᴛʜᴇᴍᴀᴛɪᴄᴀʟ ᴘʀᴏʙʟᴇᴍs ᴀɴᴅ ᴇǫᴜᴀᴛɪᴏɴs.
⦿ /tgm ➠ ᴜᴘʟᴏᴀᴅs ᴀ ᴘʜᴏᴛᴏ (ᴜɴᴅᴇʀ 𝟻ᴍʙ) ᴛᴏ ᴛʜᴇ ᴄʟᴏᴜᴅ ᴀɴᴅ ɢɪᴠᴇs ᴀ ʟɪɴᴋ.
⦿ /tr ➠ ᴛʀᴀɴsʟᴀᴛᴇs ᴛᴇxᴛ.
⦿ /google ➠ sᴇᴀʀᴄʜᴇs ғᴏʀ ɪɴғᴏʀᴍᴀᴛɪᴏɴ ᴏɴ ɢᴏᴏɢʟᴇ.
⦿ /gemini ➠ ᴀʙᴏᴜᴛ ᴀɴʏ ǫᴜᴇʀʏ ᴇx - /gemini lord ram.
⦿ /image ➠ ᴇx - /image lord ram ᴅᴏᴡɴʟᴏᴀᴅ ᴀɴʏ ɪᴍᴀɢᴇs.
⦿ /reel ➠ ᴅᴏᴡɴʟᴏᴀᴅ ɪɴsᴛᴀɢʀᴀᴍ ʀᴇᴇʟs ᴇx - /reel INSTAGRAM REEL LINK
⦿ /afk ➠  Wɪᴛʜ ᴛʜɪs ʏᴏᴜ ᴄᴀɴ sᴇᴇ ᴀғᴛᴇʀ ʜᴏᴡ ʟᴏɴɢ ʏᴏᴜ ᴀʀᴇ ᴄᴏᴍɪɴɢ ᴏɴʟɪɴᴇ.
'''
    HELP_Action = '''Aᴄᴛɪᴏɴ

Aᴄᴛɪᴏɴ ᴄᴏᴍᴍᴀɴᴅꜱ:

» ᴀᴠᴀɪʟᴀʙʟᴇ ᴄᴏᴍᴍᴀɴᴅs ꜰᴏʀ Bᴀɴs & Mᴜᴛᴇ :

 ❍ /kickme: kicks the user who issued the command

Admins only:
 ❍ /ban <userhandle>: bans a user. (via handle, or reply)
 ❍ /sban <userhandle>: Silently ban a user. Deletes command, Replied message and doesn't reply. (via handle, or reply)
 ❍ /tban <userhandle> x(m/h/d): bans a user for x time. (via handle, or reply). m = minutes, h = hours, d = days.
 ❍ /unban <userhandle>: unbans a user. (via handle, or reply)
 ❍ /kick <userhandle>: kicks a user out of the group, (via handle, or reply)
 ❍ /mute <userhandle>: silences a user. Can also be used as a reply, muting the replied to user.
 ❍ /tmute <userhandle> x(m/h/d): mutes a user for x time. (via handle, or reply). m = minutes, h = hours, d = days.
 ❍ /unmute <userhandle>: unmutes a user. Can also be used as a reply, muting the replied to user.
__
𝐒ᴘᴇᴄɪᴀʟ 𝐂ᴏᴍᴍᴀɴᴅs 𝐒ᴜᴘᴘᴏʀᴛ 𝐀ʟʟ 𝐄xᴀᴍᴘʟᴇ  -  Sonali 𝚋𝚊𝚗 Sonali 𝚖𝚞𝚝𝚎 Sonali 𝚙𝚛𝚘𝚖𝚘𝚝𝚎 ..... 𝚎𝚝𝚌
'''
    HELP_Search = '''Sᴇᴀʀᴄʜ

Sᴇᴀʀᴄʜ ᴄᴏᴍᴍᴀɴᴅꜱ:

• /google <query> : Search the google for the given query.
• /app <query>  : Search playstore apps for the given query.
• /stack <query>  : Search stackoverflow for the given query.
• /image (/imgs) <query> : Get the images regarding to your query

Example:
/google hindi songs: return top 5 reuslts.
'''

    HELP_Font = '''ғᴏɴᴛ

ʜᴇʀᴇ ɪs ᴛʜᴇ ʜᴇʟᴘ ғᴏʀ ᴛʜᴇ ғᴏɴᴛ ᴍᴏᴅᴜʟᴇ:

ғᴏɴᴛ ᴍᴏᴅᴜʟᴇ:

ʙʏ ᴜsɪɴɢ ᴛʜɪs ᴍᴏᴅᴜʟᴇ ʏᴏᴜ ᴄᴀɴ ᴄʜᴀɴɢᴇ ғᴏɴᴛs ᴏғ ᴀɴʏ ᴛᴇxᴛ!

◌ /font [ᴛᴇxᴛ]
'''
    
    HELP_TG = '''Ⓣ-ɢʀᴀᴘʜ
Ⓣ-ɢʀᴀᴘʜ ᴄᴏᴍᴍᴀɴᴅꜱ:

ᴄʀᴇᴀᴛᴇ ᴀ ᴛᴇʟᴇɢʀᴀᴘʜ ʟɪɴᴋ ᴀɴʏ ᴍᴇᴅɪᴀ!

◌ /tgm [ʀᴇᴘʟʏ ᴛᴏ ᴀɴʏ ᴍᴇᴅɪᴀ]

◌ /tgt [ʀᴇᴘʟʏ ᴛᴏ ᴀɴʏ ᴍᴇᴅɪᴀ]
'''

    HELP_Couples = '''ᴄᴏᴜᴘʟᴇs

ʜᴇʀᴇ ɪs ᴛʜᴇ ʜᴇʟᴘ ғᴏʀ ᴛʜᴇ ᴄᴏᴜᴘʟᴇs ᴍᴏᴅᴜʟᴇ:

◌ /wish : ᴀᴅᴅ ʏᴏᴜʀ ᴡɪsʜ ᴀɴᴅ sᴇᴇ ɪᴛs ᴘᴏssɪʙɪʟɪᴛʏ!
◌ /love : ᴀᴅᴅ ᴛᴡᴏ ɴᴀᴍᴇs ᴀɴᴅ sᴇᴇ ʟᴏᴠᴇ ᴘᴏssɪʙɪʟɪᴛʏ! ʟɪᴋᴇ ʀᴀᴊᴀ + sᴏɴᴀ
◌ /couples : ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ ᴀɴᴅ sᴇᴇ ɢʀᴏᴜᴘs ᴄᴏᴜᴘʟᴇs.
'''
